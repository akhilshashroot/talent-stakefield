
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content border-0">
          <div class="view show" id="modal-enquirenow-view">
            <div class="modal-header border-0 bg-dark px-4">
              <h4 class="modal-title text-light">Enquire Now</h4>
              <button class="btn-close btn-close-white" type="button" data-dismiss="modal" aria-label="btn-close "></button>
            </div>
            <div class="modal-body px-4">
              <p class="fs-ms text-muted">Please Provide following details</p>
              <form method="post" id="contactUsForm" class="waituk_contact-form" novalidate="novalidate" action="#" enctype="multipart/form-data">
              <input type="hidden" id="idkl" name="idkl" value="">
            
              
                                           <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="text" placeholder="NAME *" id="name" name="name" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="email" placeholder="EMAIL *" id="email" name="email" class="form-control">
                                                </div>
                                            </div>


                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <input type="text" placeholder="Phone number" id="phone" name="phone" class="form-control">
                                                </div>
                                            </div>
                                           

                                            <!-- <div class="col-md-6 justify-center">

                                            </div> -->
                                            <!-- <div class="btn-container mx-auto">
                                                <button id="btn_sent" class="btn btn-primary btn-arrow">SUBMIT</button>
                                                <p id="error_message"> </p>
                                            </div> -->
                                            <div class="btn-container mx-auto pt-5">
                                            <button class="btn btn-primary d-block w-100" id="submit" type="submit">Enquire Now</button>
 </p>
                                            </div>

                                    
                                </div></form>
               


              </form>
            </div>
          </div>

        </div>
      
    </div>
    </div>