
<style>
  select.form-control{
    display: inline;
    width: 200px;
    margin-left: 25px;
  }

  .w3-container{
    padding: 4rem;
    position: relative;
    }
</style>


    <!-- Create the drop down filter -->
    <!-- Set up the datatable -->
    <div class="w3-container"> 
    <h2 class="title custom text-center" id="verified-sec" style="margin-top: 30px;" rel="₹">Talents Pool</h2>

    <table class="table table-hover" id="filterTable">
      <thead class="tdhcc">
        <tr>
          <th scope="col">Sl No</th>
          <th scope="col">Talent ID</th>
          <th scope="col">Skillset </th>
          <th scope="col">Experience </th>
          <th scope="col">Turnaround time</th>
          <th scope="col">Availability </th>
          <th scope="col">Rate </th>
          <th scope="col">Action </th>
           
        </tr>
      </thead>

      <!-- <tfoot>
        <tr>
          <th scope="col">Sl No</th>
          <th scope="col">Talent ID</th>
          <th scope="col">Skillset </th>
          <th scope="col">Experience </th>
          <th scope="col">Turnaround time</th>
          <th scope="col">Availability </th>
          <th scope="col">Rate </th>
          <th scope="col">Action </th>
           
        </tr>
      </tfoot> -->
      <tbody>
      </tbody>

    </table>
</div>
 
<?php /**PATH D:\xamppp\htdocs\hashroot-enquiry\resources\views/staketalent.blade.php ENDPATH**/ ?>